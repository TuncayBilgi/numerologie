# Numérologie

Voyez la vie en base 10 en associant un chiffre à votre prénom.

## Initialisation

Une fois cloné le projet on :

1. installe les dépendances : `npm install`
2. initialise la base de donnée `npm run init`

## Lancement du serveur

`npm start`
